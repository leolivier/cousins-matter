#!/bin/bash

function download_avatar() {
  URL="$1"
  # Récupère l'en-tête Content-Type
  MIME_TYPE=$(curl -sI "$URL" | grep -i 'Content-Type' | awk '{print $2}' | tr -d '\r')
  # Associe le type MIME à une extension de fichier
  EXTENSION=""
  case "$MIME_TYPE" in
    image/jpeg)
      EXTENSION=".jpeg"
      ;;
    image/png)
      EXTENSION=".png"
      ;;
    image/gif)
      EXTENSION=".gif"
      ;;
    # Ajoutez d'autres types MIME si nécessaire
    *)
      echo "Type MIME inconnu: $MIME_TYPE"
      exit 1
      ;;
  esac

  # Génère un nom de fichier unique et télécharge l'image
  FILENAME=$(echo $URL|sed -e 's/^.*=//')"$EXTENSION"
  curl -o "$FILENAME" "$URL"

  echo "Image téléchargée sous le nom : $FILENAME"
}

set -x
for avatar in $(awk -e 'BEGIN{FS=","} { print $8; }' ../../generated-members-2.csv);
do
  if [[ $avatar != "avatar" ]];
  then
    download_avatar $avatar;
  fi;
done
